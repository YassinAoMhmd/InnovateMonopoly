package innovateMonopoly;

  enum SquareType {
    STREET, SURPRISE, JUDGE, TAX, REST
  }
