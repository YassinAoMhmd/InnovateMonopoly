package innovateMonopoly;

enum StatesGame {
    START_SHIFT,
    AFTER_JAIL,
    AFTER_ADVANCE,
    AFTER_PURCHASE,
    AFTER_MANAGE
}
