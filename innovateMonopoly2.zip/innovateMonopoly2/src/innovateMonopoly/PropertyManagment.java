package innovateMonopoly;

public enum PropertyManagment {
    SELL, MORTGAGE, CANCEL_MORTGAGE, BUILD_HOME, BUILD_HOTEL, FINISH
}
