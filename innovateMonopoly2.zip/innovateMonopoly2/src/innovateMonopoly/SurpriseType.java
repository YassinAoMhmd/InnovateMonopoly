package innovateMonopoly;

enum SurpriseType {
    GOJAIL, GOBOX, PAYCOLLECT, BYHOUSEHOTEL, PERPLAYER, EXITJAIL
}
