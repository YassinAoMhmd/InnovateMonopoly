package innovateMonopoly;

import java.util.ArrayList;

public class SquareTax extends Square{

    private float amount;

    SquareTax(float amount,String name) {
        super(name);
        this.amount = amount;
    }

    void receivePlayer_tax(int current, ArrayList<Player> all){
        if(playerCorrect(current,all)){
            report(current, all);

            all.get(current).payTax(amount);
        }
    }

    float getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "SquareTax{" +
                "name='" + super.getName() + '\'' +
                ", amount=" + amount +
                '}';
    }
}
