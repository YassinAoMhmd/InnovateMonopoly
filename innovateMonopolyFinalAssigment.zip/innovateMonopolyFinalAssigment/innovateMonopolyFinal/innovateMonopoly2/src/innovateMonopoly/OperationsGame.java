package innovateMonopoly;

public enum OperationsGame {
    SHIFT_PASS, EXIT_JAIL, ADVANCE, BUY, MANAGE
}
