package innovateMonopoly;

public enum ExitJail {
    PAYING, THROWING
}
