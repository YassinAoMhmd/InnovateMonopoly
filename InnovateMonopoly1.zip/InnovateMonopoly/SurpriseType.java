package InnovateMonopoly;

enum SurpriseType {
    GOJAIL, GOBOX, PAYCOLLECT, BYHOUSEHOTEL,
    PERPLAYER, EXITJAIL
}
