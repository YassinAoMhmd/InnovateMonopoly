package InnovateMonopoly;

enum SquareType {
    STREET, SURPRISE, JUDGE, TAX, REST
}
