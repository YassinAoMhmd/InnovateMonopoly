package InnovateMonopoly;

public class Surprise {
}
