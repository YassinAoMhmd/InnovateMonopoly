package InnovateMonopoly;

public class Square {
    private String name;

    Square(String _name){
        name = _name;
    }

    String getNombre() {
        return name;
    }
}
