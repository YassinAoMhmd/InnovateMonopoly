package innovateMonopoly;

import java.util.ArrayList;

public class SurpriseGoSquare extends Surprise{
    private String text;
    private int value;
    private Board board;

    SurpriseGoSquare(Board board, int value, String text){
        super(text);
        this.board = board;
        this.value = value;
    }

    void applyPlayer(int current, ArrayList<Player> all){
        int currentSquare,throwing,newPosition;

        if(playerCorrect(current, all)){
            report(current, all);

            currentSquare = all.get(current).getNumCurrentSquare();

            throwing = board.calculateShot(currentSquare, value);

            newPosition = board.newPosition(currentSquare,throwing);

            all.get(current).moveToSquare(newPosition);

            board.getSquare(newPosition).receivePlayer(current,all);
        }
    }

}
