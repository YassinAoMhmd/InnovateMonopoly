package innovateMonopoly;

import java.util.ArrayList;

public class Square {
    private String name;

    Square(String name){
        this.name = name;
    }

    protected void report(int current, ArrayList<Player> all){
        Journal.getInstance().occurEvent("The player " + all.get(current).getName() + " has fallen into this box" + name + "Box Information: \n" + toString());
    }

    @Override
    public String toString() {
        return "Square Rest{" +
                "name='" + name + '\'';
    }

    public boolean playerCorrect(int current, ArrayList<Player> all){
        if(current >= 0 && current < all.size()){
            return true;
        }
        else{
            return false;
        }
    }

    void receivePlayer(int icurrent, ArrayList<Player> all){
        report(icurrent, all);
    }

    public String getName(){
        return name;
    }

}
