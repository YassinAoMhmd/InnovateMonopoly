package innovateMonopoly;

import java.util.ArrayList;

public class SquareJudge extends Square{

    private int jail;

    SquareJudge(int numSquareJail, String name){
        super(name);
        jail = numSquareJail;
    }

    void receivePlayer_judge(int current, ArrayList<Player> all){
        if(playerCorrect(current, all)){
            report(current, all);

            all.get(current).incarcerate(jail);
        }
    }

    public String toString() {
        return "SquareJudge{" +
                "name='" + super.getName() + '\'' +
                ", jail=" + jail +
                '}';
    }
}
