package innovateMonopoly;

import java.util.ArrayList;

public class SurprisePlayer extends Surprise {
    private Board board;
    private String text;
    private int value;

    SurprisePlayer(Board board, int value, String text){
        super(text);
        this.board = board;
        this.value = value;
    }

    void applyPlayer(int current, ArrayList<Player> all){
        if(playerCorrect(current, all)){
            report(current, all);

            SurprisePayCollect surprise;

            surprise = new SurprisePayCollect(this.board, -1* value, "all players except current must pay");

            for(int i=0 ; i<all.size(); i++){
                if(all.get(i) != all.get(current)){
                    surprise.applyPlayer(i,all);
                }
            }

            surprise.applyPlayer(current,all);
        }
    }

    public String toString() {
        return "SurprisePlayer{" +
                "text='" + text + '\'' +
                ", value=" + value +
                '}';
    }
}
