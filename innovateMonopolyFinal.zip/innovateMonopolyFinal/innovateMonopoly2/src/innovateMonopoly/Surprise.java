package innovateMonopoly;

import java.util.ArrayList;

public abstract class Surprise {
    private String text;

    Surprise(String text){
        this.text = text;
    }

    public boolean playerCorrect(int current, ArrayList<Player> all){
        if(current < all.size() && current >= 0){
            return true;
        }else{
            return false;
        }
    }

    protected void report(int current, ArrayList<Player> all){
       Journal.getInstance().occurEvent("A surprise is being applied to the player " + all.get(current).getName());
    }

    abstract void applyPlayer(int current, ArrayList<Player> all);

    public String toString() {
        return "Surprise: " + text;
    }
}
