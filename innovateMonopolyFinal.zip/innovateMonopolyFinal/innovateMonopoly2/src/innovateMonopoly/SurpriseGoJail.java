package innovateMonopoly;

import java.util.ArrayList;

public class SurpriseGoJail extends Surprise{
    private String text;
    private int value;
    private Board board;

    SurpriseGoJail(Board board){
        super("You go to the jail");
        this.board = board;
        this.value = board.getJail();
    }

    void applyPlayer(int current, ArrayList<Player> all){
        if(playerCorrect(current, all)){

            report(current, all);

            all.get(current).incarcerate(board.getJail());
        }
    }

    public String toString() {
        return "SurpriseGoJail{" +
                "text='" + text + '\'' +
                ", value=" + value +
                '}';
    }
}
