package innovateMonopoly;

import java.util.ArrayList;

public class SquareStreet extends Square{
    private TitleProperty titleproperty;

    SquareStreet(TitleProperty title){
        super(title.getName());
        titleproperty = title;
    }

    void receivePlayer_street(int icurrent, ArrayList<Player> all){
        if(playerCorrect(icurrent, all)){
            this.report(icurrent, all);
            Player player;
            player = all.get(icurrent);

            if(!titleproperty.haveProprietor()){
                player.canBuySquare();
            }else {
                titleproperty.transferRent(player);
            }
        }
    }

    TitleProperty getTitleProperty(){
        return titleproperty;
    } //Consultor del titulo de propiedad

    @Override
    public String toString() {
        return "SquareStreet{" +
                "titleProperty=" + titleproperty +
                '}';
    }
}
