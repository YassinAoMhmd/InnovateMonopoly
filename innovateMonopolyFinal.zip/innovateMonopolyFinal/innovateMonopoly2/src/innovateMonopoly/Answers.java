package innovateMonopoly;

public enum Answers {
    NO, YES
}
