package innovateMonopoly;

public class PlayerSpeculator extends Player{
    protected static int HousesMax = 8;
    protected static int HotelesMax = 8;
    protected static int factorSpeculator = 2;
    private int numCurrentSquare;
    private float deposit;


    PlayerSpeculator(Player player,float deposit){
        super(player);
        this.deposit = deposit;
        updateOwnerByConversion(player);
    }

    void updateOwnerByConversion(Player player){
        for(int i=0; i < player.getProperties().size();i++){
            player.getProperties().get(i).updateOwnerForConversion(this);
        }
    }


    boolean mustBeIncarcerated(){
        if(incarcelated){
            return false;
        }else{
            if(haveSafeConduct()){
                super.losingSafeConduct();

                Journal.getInstance().occurEvent("The player has just been saved from jail by means of his safe-conduct card and consequently loses it.");

                return false;
            }
            else if(super.canSpend(deposit)){
                Journal.getInstance().occurEvent("The player has just been saved from jail by means of his safe-conduct card and consequently loses it.");

                pay(deposit);

                return false;
            }
            else {
                return true;
            }
        }
    }

    boolean payTax (float amount){
        if(incarcelated){
            return false;
        }
        else{
            boolean payTax;

            payTax  = pay(amount/2);

            return payTax;
        }
    }

    public String toString() {
        return "Player Speculator{" + super.toString() + '}';
    }

    int getHousesMax() {
        return super.getHouseMax() * factorSpeculator;
    }

    int getHotelesMax() {
        return super.getHotelsMax()* factorSpeculator;
    }

    protected String getName() {
        return super.getName();
    }


    private boolean canBuildHouse(TitleProperty property){
        if(property.getNumHouses() < HousesMax && this.getBalance() >= property.getPriceBuild()){
            return true;
        }else{
            return false;
        }
    }

    private boolean canBuildHotel(TitleProperty property){
        if(property.getNumHouses() < HotelesMax && this.getBalance() >= property.getPriceBuild()){
            return true;
        }else{
            return false;
        }
    }
}
