package innovateMonopoly;

import java.util.ArrayList;

public class SurpriseSpeculator extends Surprise{
    private int deposit;
    private String text;

    SurpriseSpeculator(String text, int deposit){
        super(text);
        this.deposit = deposit;
    }

    void applyPlayer(int current, ArrayList<Player> all){
        if (playerCorrect(current, all)) {
            report(current, all);

            PlayerSpeculator playerSpeculator;
            playerSpeculator = new PlayerSpeculator(all.get(current),deposit);

            all.remove(current);
            all.add(playerSpeculator);
        }
    }


}
