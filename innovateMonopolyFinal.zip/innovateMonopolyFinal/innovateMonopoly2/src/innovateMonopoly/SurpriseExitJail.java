package innovateMonopoly;

import java.util.ArrayList;

public class SurpriseExitJail extends Surprise{
    private SurpriseDeck deck;

    SurpriseExitJail(SurpriseDeck deck){
        super("You are getting out of jail");
        this.deck = deck;
    }

    void applyPlayer(int current, ArrayList<Player> all) {
        if(playerCorrect(current, all)){
            boolean find = false;

            report(current, all);

            for(int i=0; !find && all.size() > i;i++){
                if(all.get(i).haveSafeConduct()){
                    find = true;
                }
            }

            if(!find){
                all.get(current).obtainSafeConduct(this);

                exitDeck();
            }
        }

    }

    void exitDeck(){
        deck.notenableSpecialCards(this);
    }

    void used(){
        deck.enableSpecialCards(this);
    }


}
