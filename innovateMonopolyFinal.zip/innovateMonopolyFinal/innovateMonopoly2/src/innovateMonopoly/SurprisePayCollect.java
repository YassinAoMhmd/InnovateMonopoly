package innovateMonopoly;

import java.util.ArrayList;

public class SurprisePayCollect extends Surprise{
    private String text;
    private int value;
    private Board board;

    SurprisePayCollect(Board board, int value, String text){
        super(text);
        this.value = value;
        this.board = board;
    }

    void applyPlayer(int current, ArrayList<Player> all){
        if(playerCorrect(current,all)){
            report(current,all);

            all.get(current).changeBalance(value);
        }
    }

    public String toString() {
        return "SurprisePayCollect{" +
                "text='" + text + '\'' +
                ", value=" + value +
                '}';
    }
}
