package innovateMonopoly;

import java.util.ArrayList;

public class SquareSurprise extends Square{

    private Surprise surprise;
    private SurpriseDeck deck;

    SquareSurprise(SurpriseDeck deck, String name){
        super(name);
        this.deck = deck;

    }

    void receivePlayer_surprise(int icurrent, ArrayList<Player> all){
        if(playerCorrect(icurrent, all)){
            surprise = deck.next();

            this.report(icurrent, all);

            surprise.applyPlayer(icurrent, all);
        }
    }
}
